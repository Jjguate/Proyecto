#**Manual de Proyecto Calculadora con Notacion Polaca Inversa**

> Se le pedira al usuario que ingrese una **_ecuacion_** escrita con _Notacion Polaca Inversa_ donde cada elemento de la ecuacion
tiene que ser separado por un guion **(-)**, sin importar si el elemento es un numero o un operador.

> Si el usuario recibe un mensaje relacionado a un **error** entonces el usuario tendra que ingresar una operacion u ecuacion diferente.

> Cada vez que se ingrese una ecuacion valida, esta sera evaluada por el programa, asi que si es valida se mostrara la forma en que cada elemento es separado y se le preguntara al usuario si desea seguir ingresando mas ecuaciones u operaciones, por lo cual el usuario necesita responder con una "**s**" si desea ingresar otra ecuacion o con una "**n**" si ya no ingresara nada mas. 


De esta manera el programa resolvera todas las operaciones, las escribira en un archivo de texto **_Proyecto.txt_** y devolvera en pantalla la lista de resultados tal y como las ecuaciones fueron ingresadas, despues la lista de resultados ordenados ascendentemente y despues descendentemente. 


















