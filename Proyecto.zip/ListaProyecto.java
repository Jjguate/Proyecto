/**
 * Clase para crear la lista que guardara los resultados de la operacion y que
 * tambien los ordena ascendente y descendentemente.
 * @author Juan Jose Santos
 * @version 1.0
 * @since 1.0
 */
public class ListaProyecto{
  NodoProyecto inicio;
  int size;

  /**
   * Constructor que inicializa la lista del programa.
   * @since 1.0
   */
  public ListaProyecto(){
    this.inicio = null;
    size = 0;
  }

  /**
   * metodo que agrega los resultados obtenidos de la operacion a la pila.
   * @param dato es el resultado obtenido al resolver la operacion ingresada
   * por el usuario.
   */

  public void agregar(Double dato){
    NodoProyecto nodo = new NodoProyecto(dato);
    nodo.dato = dato;
    nodo.next = null;

    if(inicio == null){
        inicio = nodo;
        size = 1;
    }else{
      NodoProyecto auxiliar = inicio;
      for(int i = 0; i < size; i ++){
        if(auxiliar.next == null){
          auxiliar.next = nodo;
          size ++;
          break;
        }
        auxiliar = auxiliar.next;
      }
    }
  }

  /**
   * metodo que muestra todos los datos de la lista.
   */

  public void listar(){
    NodoProyecto auxiliar = inicio;
         for(int i=0; i<size; i++){
           System.out.print(auxiliar.dato+"-->");
           auxiliar = auxiliar.next;
         }
         System.out.println();
         System.out.println();
  }

  /**
   * metodo que muestra el tamanio de la lista
   * @return devuelve el numero de elementos que tiene la lista
   */

  public int size(){
    return size;
  }

  /**
   * metodo que ordena los datos de la lista en forma ascendente.
   */

  public void ordenarResultadosAscendentemente(){
      NodoProyecto auxiliar = inicio;
      for(int i=0; i<size; i++){
        // String nombreProducto = auxiliar.dato.getNombre();
         NodoProyecto NodoComparacion = auxiliar.next;
         NodoProyecto menor = auxiliar;
          for(int j=1; j<size; j++){
            if(NodoComparacion == null){
               break;
            }
             //String nombreAComparar = NodoComparacion.dato.getNombre();
               if(menor.dato > NodoComparacion.dato){
                   menor = NodoComparacion;
               }
                   NodoComparacion = NodoComparacion.next;
          }
             Double temporal = auxiliar.dato;
             auxiliar.dato = menor.dato;
             menor.dato = temporal;

             auxiliar = auxiliar.next;
       }
    }

    /**
     * metodo que ordena los datos de la lista en forma descendente.
     */

    public void ordenarResultadosDescendentemente(){
        NodoProyecto auxiliar = inicio;
        for(int i=0; i<size; i++){
          // String nombreProducto = auxiliar.dato.getNombre();
           NodoProyecto NodoComparacion = auxiliar.next;
           NodoProyecto mayor = auxiliar;
            for(int j=1; j<size; j++){
              if(NodoComparacion == null){
                 break;
              }
               //String nombreAComparar = NodoComparacion.dato.getNombre();
                 if(mayor.dato < NodoComparacion.dato){
                     mayor = NodoComparacion;
                 }
                     NodoComparacion = NodoComparacion.next;
            }
               Double temporal = auxiliar.dato;
               auxiliar.dato = mayor.dato;
               mayor.dato = temporal;

               auxiliar = auxiliar.next;
         }
      }
}
