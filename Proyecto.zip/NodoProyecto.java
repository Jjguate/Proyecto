/**
 * Clase para crear el nodo que se usara para todo el programa (en la pila, la lista).
 * @author Juan Jose Santos
 * @version 1.0
 * @since 1.0
 */
public class NodoProyecto{
   public Double dato;
   public NodoProyecto next;

   /**
    * Constructor que inicializa la el nodo del programa
    * @since Quiniela 1.0
    * @param dato que esta dentro de la cadena String que ingresa el usuario en el
    * programa pincipal.
    */
   public NodoProyecto(Double dato){
     this.dato = dato;
     this.next = null;
   }

}
