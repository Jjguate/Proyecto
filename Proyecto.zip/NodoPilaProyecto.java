/**
 * Clase del nodo que sera utilizado para la pila del programa.
 * @author Juan Jose Santos
 * @version 1.0
 * @since 1.0
 */

public class NodoPilaProyecto{
  double data;
  NodoPilaProyecto next;

  /**
   * Constructor que inicializa el nodo de la pila del programa
   * @since 1.0
   */
  public NodoPilaProyecto(double data){
    this.data = data;
    this.next = null;
  }
}
