/**
 * Clase para realizar la operacion recibida del usuario y proveer el resultado.
 * @author Juan Jose Santos
 * @version 1.0
 * @since 1.0
 */
import java.util.ArrayList;
import java.util.StringTokenizer;
public class RPNCalc implements OperacionCalculadora{

	PilaProyecto pilita = new PilaProyecto();

	/**
	 * metodo que indica si el digito recibido es un operador matematico o si
	 * no lo es.
	 * @param next elemento de la cadena recibida que se esta separando.
	 */

	 public boolean operador(String next){
	    return (next.equals("PLUS") || next.equals("LESS") || next.equals("TIMES") || next.equals("DIVIDE"));
	 }

	 /**
    * metodo que resuelve la operacion ingresada por el usuario
		* @throws NumberFormatException e indica si la operacion no es valida para resolver
		* con notacion polaca inversa dependiendo del digito recibido.
		* @param ecuacion es la cadena que se va a separar x elementos y que va a ser resuelta
		* por el metodo.
    */

	 public Double calcular(String ecuacion) {
		// elimina espacios vacios al principio de la cadena si los hubiera.
		    ecuacion = ecuacion.trim();
		    String next = null;
		    PilaProyecto pilita = new PilaProyecto();
		    StringTokenizer elemento = new StringTokenizer(ecuacion, "-");
	           while(elemento.hasMoreTokens()){
	             next = elemento.nextToken();
	             System.out.println(next);
		             if (operador(next)) {
		          // asegurando que hay suficientes numeros en la pila para poder operar.
		                if (pilita.size() > 1) {
		                   if (next.equals("PLUS")) {
		                      pilita.push(pilita.pop() + pilita.pop());
		                   } else if (next.equals("LESS")) {
		                        pilita.push(-pilita.pop() + pilita.pop());
		                   } else if (next.equals("TIMES")) {
		                      pilita.push(pilita.pop() * pilita.pop());
		                   } else if (next.equals("DIVIDE")) {
		                      double first = pilita.pop();
		                      double second = pilita.pop();
                            if (first == 0) {
		                          System.out.println("Error: La ecuacion intenta dividir por cero ");
		                        } else {
		                          pilita.push(second / first);
		                        }
		                   }
		               } else{
		                  System.out.println("Error: Un operador matematico aparecio antes de tener suficientes numeros para poder operar con NPI");
		               }
		             }else{
		                try{
		                   pilita.push(Double.parseDouble(next));
		             } catch (NumberFormatException e) {
		                   System.out.println("La cadena no es valida para operar con Notacion Polaca Inversa ");
		             }
		          }
           }
		      if (pilita.size() > 1) {
		        System.out.println("No hay suficientes operadores matematicos para evaluar todos los numeros de la ecuacion.");
		      }
       return pilita.pop();
	  }
 }
