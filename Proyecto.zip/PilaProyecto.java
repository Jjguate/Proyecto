/**
 * Clase para crear la pila que guardara y sacara los resultados de nuestra
 * operacion.
 * @author Juan Jose Santos
 * @version 1.0
 * @since 1.0
 */
public class PilaProyecto{
    NodoPilaProyecto top;
    int size;
    double remove = 0;
 /**
  * Constructor que inicializa la pila del programa
  * @since 1.0
  */
   public PilaProyecto(){
     top = null;
     size = 0;
   }

 /**
  * metodo que ingresa los datos dobles a la pila hasta esperar un operador y poder
  * calcular el resultado de la ecuacion u operacion.
  * @param data recibe un valor doble que sera ingresado en la pila.
  */

   public void push(double data){
     NodoPilaProyecto nuevo = new NodoPilaProyecto(data);
     nuevo.next = top;
     top = nuevo;
     size++;
   }

   /**
    * metodo que saca los datos dobles de la pila cuando un operador aparece y poder
    * asi calcular el resultado de la ecuacion u operacion.
    * @return valorRetorno devuelve el valor doble que esta saliendo de la pila.
    */

   public Double pop(){
     Double valorRetorno = null;
     if(top != null){
       valorRetorno = top.data;
       top = top.next;
       size--;
     }
     return valorRetorno;
   }

   /**
    * metodo que muestra la cima de la pila o sea el primer valor a sacar.
    * @return top retorna el valor que esta en la cima de la pila.
    */

   public Double getTop(){
    // System.out.println("el dato en la cima es "+top.data);
     return top.data;
   }

   /**
    * metodo que muestra si la pila esta vacia o si ya tiene elementos.
    * @return top que devueve la cima como null si esta vacia o un elemento si
    * la pila no esta vacia.
    */

   public boolean isEmpty(){
     return top == null;
   }

   /**
    * metodo que muestra el numero de elementos que estan adentro de la pila.
    * @return size devuele el tamanio de la pila.
    */

   public int size(){
      return size;
   }

}
