public class Proyecto{
  public static void main(String[] args){

    System.out.println("Estos son nuestros vuelos de la semana\n ");

  String[][] vuelos = new String[7][2];

  vuelos[0][0] = "Ciudad de origen y destino ";
  vuelos[0][1] = " ---  Dias de vuelo";
  vuelos[1][0] = " ";
  vuelos[1][1] = " ";
  vuelos[2][0] = "Guatemala / Cuba";
  vuelos[2][1] = " ---             Domingo";
  vuelos[3][0] = "Guatemala / Miami";
  vuelos[3][1] = " ---            Lunes / Miercoles/ Viernes/ Domingo";
  vuelos[4][0] = "Guatemala / New York";
  vuelos[4][1] = " ---         Miercoles / Sabado";
  vuelos[5][0] = "Guatemala / Mexico";
  vuelos[5][1] = " ---           Lunes / Martes / Viernes";
  vuelos[6][0] = "Guatemala / Colombia";
  vuelos[6][1] = " ---         Martes / Sabado";


  for (int i=0; i<7; i++){
    for (int j=0; j<2; j++){
      System.out.print(vuelos[i][j]);
    }
      System.out.println();
  }
 }
}
