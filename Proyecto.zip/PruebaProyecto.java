/**
 * Clase principal donde se recibe la operacion a realizar de parte del usuario, se
 * manda a imprimir al archivo de texto, se obtiene el resultado que tambien se mandas
 * a escribir al archivo de texto y tambien muestra la lista de resultados ordenados
 * ascendente y descendentemente.
 * @author Juan Jose Santos
 * @version 1.0
 * @throws Exception e indica si el dato ingresado por el usuario es valido.
 * @since 1.0
 */
import java.util.Scanner;
import java.io.*;
public class PruebaProyecto{
  public static void main(String[] args) {
    Scanner reader = new Scanner(System.in);
    ListaProyecto listita = new ListaProyecto();
    RPNCalc cadena = new RPNCalc();
    Double resultado = 0.0;
    String opcion = " ";
    String ecuacion;
    File archivo;
    FileWriter escribir;
    PrintWriter linea;
    archivo = new File("Proyecto.txt");

      do {
         try{
            System.out.println("ingresar la operacion en Notacion Polaca Inversa separando los digitos con"+
                              "un guion (-) usando unicamente los operadores PLUS, LESS, TIMES, DIVIDE ");
            ecuacion = reader.next();
            resultado = cadena.calcular(ecuacion);
             listita.agregar(resultado);
             System.out.println("Desea ingresar otra ecuacion? (s/n) ");
             opcion = reader.next();

             escribir = new FileWriter(archivo, true);
             linea = new PrintWriter(escribir);
             linea.println("OPERACION            RESULTADO");
             linea.println(ecuacion+"     =      "+resultado);
             linea.close();
             escribir.close();
          }catch (Exception e){
              System.out.println("Ha sucedido un error "+e);
          }

      }while (opcion.equalsIgnoreCase("s"));
         listita.listar();
         listita.ordenarResultadosAscendentemente();
         listita.listar();
         listita.ordenarResultadosDescendentemente();
         listita.listar();
  }

}
