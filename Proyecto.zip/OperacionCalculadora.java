/**
 * Clase para crear la interface del programa relacionada a la resolucion
 * la operacion que sera ingresada por el usuario y que devolvera el resultado.
 * @author Juan Jose Santos
 * @version 1.0
 * @since 1.0
 */
public interface OperacionCalculadora{
   public Double calcular(String ecuacion);
}
